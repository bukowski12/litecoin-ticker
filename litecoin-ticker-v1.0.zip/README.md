# litecoin-ticker
Chrome extension for realtime litecoin prices from Bitstamp in USD and EUR
